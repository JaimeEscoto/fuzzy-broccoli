A Pen created at CodePen.io. You can find this one at http://codepen.io/labithiotis/pen/byskq.

 Responsive checkbox set by font size, easily set the inner text for on and off states.